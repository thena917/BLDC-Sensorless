/* Copyright (C) 2016 Texas Instruments Incorporated - http://www.ti.com/
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/
/**************************************************************************
 * @file        Sensorless_Trap_Parameters_Setup.h
 * @author      MDBU Software Team
 * @brief       SPI API file for SPI Module.
 * @note        Copyright (c) 2016 Texas Instruments Incorporated.
 *              All rights reserved.
 * @date		May 2016
 ******************************************************************************/

// USER DEFINES
#define ALGO_ID						1       // 1 Indicates sensorless , 0 indicates sensored algorithms
#define ALIGN_OR_IPD				0       //  0 indicates Six pulse method , 1 indicates rotor align
//ISC User Parameters
#define ISC_MIN_BEMF				150		// Minimum BEMF below which programs skips to IPD after brake time set by ISC BRAKE TIME in ms to disscipate the residual BEMF( 1.4v *4096)/57.5 = 100
#define ISC_BRAKE_TIME              60		// [this number+1]*1ms = brake time appled once BEMF of motor is less than ISC_MIN_BEMF, if motor is spinning  during start up
//IPD User Parameters
#define IPD_ADD_BRAKE	 			30		// the (IPDRiseTime/512)+this number  IPDRiseTime is measured using timerA at 12.5MHz so 400us = 5000
#define IPD_PULSE_TIME	 			3000		// set no of clock cycles (1 clock cycles = 40nS) a voltage pulse is applied on a phase for Initial Position detection by Six pulse method
#define	IPD_DECAY_CONSTANT 			3		// how many times longer to coast the motor and wait until next pulse after braking in IPD

//Align User Parameters
#define ALIGN_SECTOR				1		// Align commutation sequence (1-6)
#define ALIGN_WAIT_TIME				500		// Number of PWM cycles to Wait during align align time seconds = [this number * 41us]

//Open Loop Acceleration User Parameters
#define ACCEL_RATE 					40		// {Hz/s}
#define ACCEL_STOP 					50000	// {mHz}
#define ACCEL_VELOCITY_INIT			10000   // {mHz}

//Closed Loop User Parameters
#define BEMF_THRESHOLD 				1960    // BEMF Integration threshold according to calculations of BEMF waveform
#define RAMP_RATE_DELAY		 		100		// This number controls the acceleration,  duty cycle is updated after ( RAMP_RATE_DELAY * 1000) clock cycles
#define RAMP_RATE					1		// This is the change in dutycycle (increment/decrement) for every update
#define COMMUTATION_BLANK_TIME 		5		// How many PWM cycles to blank before sampling the BEMF
#define PWM_BLANK_COUNTS 			5		// How many Clock cycles before the center of PWM  the BEMF is sampled

#define MAX_DUTY_CYCLE 				1000		// relative to PWM_PERIOD
#define MIN_OFF_DUTY 				250			// relative to PWM_PERIOD
#define MIN_ON_DUTY 				260			// relative to PWM_PERIOD
#define START_UP_DUTY_CYCLE			250			// relative to PWM_PERIOD
#define PWM_FACTOR					0       	//  ADC 12 bit to PWM width ratio , by default 0 represents 12 bit scaling

/* Fault handling setup */						/*ADC Max ref voltage is 3.3v ,  VCC is scaled by 0.0573 internally (5/88 Ohms bridge) so that VCC ref input to ADC never cross 3.3v The maximum supply voltage is 57.5v.*/
#define UNDER_VOLTAGE_LIMIT (712)			    /* Under Voltage set for below 10.0V - (10*4096)/57.5 = 712  */
#define OVER_VOLTAGE_LIMIT	(1780)     			/* Over Voltage set for above 20.0V  - (20*4096)/57.5 = 1424 */
#define STALLDETECT_REV_THRESHOLD	(1)			/* Number of revolutions below which stall fault will be flagged */
#define STALLDETECT_TIMER_THRESHOLD (200)		/* Time in milli seconds above which if motor doesnt spin min revolutions specified above(STALLDETECT_REV_THRESHOLD) a stall fault is triggered */
#define MOTOR_PHASE_CURRENT_LIMIT (900)        /* Defines the max allowed motor phase current in digital counts . Motor phase current is monitored every electrical cycle , and when ever current limit is reached an OC fault is Triggered */
#define AUTO_FAULT_RECOVERY_TIME (3000)      	/*  Delay in milli Seconds after which system reinitialises itself if fault gets cleared */

/* DRV8323 SPI REGISTER SETTINGS*/
/* SPI_REG_02 : DRIVER CONTROL */
#define RSVD        (0x00)         /*  */
#define DIS_CPUV    (0x00)         /*  */
#define DIS_GDF     (0x00)         /*  */
#define OTW_REP     (0x00)         /*  */
#define PWM_MODE    (0x00)         /*  */
#define PWM_COM     (0x00)         /*  */
#define PWM_DIR     (0x00)         /*  */
#define COAST_BIT   (0x00)         /*  */
#define BRAKE_BIT   (0x00)         /*  */
#define CLR_FLT     (0x00)         /*  */

/* SPI_REG_03 : GATE DRIVE HS */
#define LOCK_BIT    (0x03)         /*  */
#define IDRIVEP_HS  (0x0F)         /*  */
#define IDRIVEN_HS  (0x0F)         /*  */

/* SPI_REG_04 : GATE DRIVE LS */
#define CBC         (0x01)         /*  */
#define TDRIVE      (0x03)         /*  */
#define IDRIVEP_LS  (0x0F)         /*  */
#define IDRIVEN_LS  (0x0F)         /*  */

/* SPI_REG_05 : OCP CONTROL */
#define TRETRY      (0x00)         /*  */
#define DEAD_TIME   (0x00)         /*  */
#define OCP_MODE    (0x01)         /*  */
#define OCP_DEG     (0x01)         /*  */
#define VDS_LVL     (0x09)         /*  */

/* SPI_REG_06 : CSA CONTROL */
#define CSA_FET     (0x00)         /*  */
#define VREF_DIV    (0x01)         /*  */
#define LS_REF      (0x00)         /*  */
#define CSA_GAIN    (0x01)         /*  */
#define DIS_SEN     (0x00)         /*  */
#define CSA_CAL_A   (0x00)         /*  */
#define CSA_CAL_B   (0x00)         /*  */
#define CSA_CAL_C   (0x00)         /*  */
#define SEN_LVL     (0x03)         /*  */

