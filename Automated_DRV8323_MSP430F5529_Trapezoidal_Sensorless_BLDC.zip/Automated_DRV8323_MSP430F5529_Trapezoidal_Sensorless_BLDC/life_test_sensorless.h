/*
 * life_test_sensorless.h
 *
 *  Created on: May 27, 2019
 *      Author: tshanmugam
 */

#ifndef LIFE_TEST_SENSORLESS_H_
#define LIFE_TEST_SENSORLESS_H_

typedef struct {
	uint32_t	direction;
	uint32_t	speed;
	uint32_t	duration;
} lifeTestItem_s;

void lifeTestInitSensorless( void );
void lifeTestUpdateSensorless( void );
void lifeTestUpdateRTCSensorless( void );


#endif /* LIFE_TEST_SENSORLESS_H_ */
