#include "global.h"
#include "mdbu_global.h"
#include "life_test_sensorless.h"

uint32_t		m_realTimeClock_ms;
uint8_t			m_lifeTestState;
uint8_t			m_nextState;
uint32_t		m_offTime_ms;
uint32_t		m_onTime_ms;
uint8_t			m_lifeTestItemIdx;

lifeTestItem_s m_lifeTestSpec[1] =
{
	{ TRUE, 1000, 2000 },
};

void lifeTestInitSensorless( void )
{
	m_lifeTestState = 0;
	m_lifeTestItemIdx = 0;
	m_nextState = 0;
	m_realTimeClock_ms = 0;
	m_onTime_ms = m_realTimeClock_ms + 1000;
	m_offTime_ms = 0;
	drv832x_setGPIO(0x01, EN_DRV, 1);
	drv832x_setMtrParam( MTR_PARAM_SPEED, 500 );


}

void lifeTestUpdateRTCSensorless( void )
{
	m_realTimeClock_ms += 100;
}

void lifeTestUpdateSensorless( void )
{

	switch( m_lifeTestState )
	{

	case 0:
		if( m_realTimeClock_ms > m_onTime_ms )
		{
			drv832x_setMtrParam( MTR_PARAM_SPEED, m_lifeTestSpec[m_lifeTestItemIdx].speed);
			drv832x_setMtrParam( MTR_PARAM_DIR, m_lifeTestSpec[m_lifeTestItemIdx].direction );
			m_offTime_ms = m_realTimeClock_ms + m_lifeTestSpec[m_lifeTestItemIdx].duration;
			drv832x_StartMotor();
			m_nextState = 1;
		}
		break;

	case 1:
		if( m_realTimeClock_ms > m_offTime_ms )
		{
			drv832x_StopMotor();
			m_onTime_ms = m_realTimeClock_ms + m_lifeTestSpec[m_lifeTestItemIdx].speed; // assumes a deceleration of 1 unit/sec^2
			m_nextState = 0;

			m_lifeTestItemIdx++;
			if( m_lifeTestItemIdx >= ( sizeof( m_lifeTestSpec ) / sizeof( lifeTestItem_s ) ) )
			{
				m_lifeTestItemIdx = 0;
			}

		}
		break;
	}

	if( m_nextState != m_lifeTestState )
	{
		m_lifeTestState = m_nextState;
	}

}
